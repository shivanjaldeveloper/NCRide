import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  StatusBar,
  ActivityIndicator,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../navigation/types';
import { Colors, Typography, fscale, vscale, Spacing } from '../../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Splash'>;

const SplashScreen = ({ navigation }: Props) => {
  const logoScale = useRef(new Animated.Value(0.6)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const loaderOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Logo entrance
    Animated.sequence([
      Animated.parallel([
        Animated.spring(logoScale, {
          toValue: 1,
          tension: 60,
          friction: 8,
          useNativeDriver: true,
        }),
        Animated.timing(logoOpacity, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ]),
      // Text fade
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }),
      // Loader fade
      Animated.timing(loaderOpacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();

    // Navigate after splash
    const timer = setTimeout(() => {
      navigation.replace('Onboarding');
    }, 2800);

    return () => clearTimeout(timer);
  }, [navigation, logoScale, logoOpacity, textOpacity, loaderOpacity]);

  return (
    <View style={styles.root}>
      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle="light-content"
      />
      <LinearGradient
        colors={[Colors.splashTop, Colors.splashMid, Colors.splashBot]}
        locations={[0, 0.45, 1]}
        style={styles.gradient}
      >
        {/* Glow behind logo */}
        <View style={styles.glowRing} />

        {/* Logo */}
        <Animated.View
          style={[
            styles.logoWrap,
            { opacity: logoOpacity, transform: [{ scale: logoScale }] },
          ]}
        >
          <View style={styles.logoBox}>
            {/* Bus icon placeholder — replace with actual SVG/image */}
            <Text style={styles.logoEmoji}>🚌</Text>
          </View>
        </Animated.View>

        {/* Brand text */}
        <Animated.View style={{ opacity: textOpacity, alignItems: 'center' }}>
          <Text style={styles.brandName}>NCRide</Text>
          <Text style={styles.brandSub}>NOIDA · DELHI NCR RIDES</Text>
        </Animated.View>

        {/* Bottom loader */}
        <Animated.View style={[styles.bottomWrap, { opacity: loaderOpacity }]}>
          <ActivityIndicator color={Colors.textInverse} size="small" />
          <Text style={styles.region}>INDIA · NCR</Text>
        </Animated.View>
      </LinearGradient>
    </View>
  );
};

const styles = StyleSheet.create({
  root: { flex: 1 },
  gradient: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  glowRing: {
    position: 'absolute',
    width: fscale(220),
    height: fscale(220),
    borderRadius: fscale(110),
    backgroundColor: Colors.accent,
    opacity: 0.06,
  },

  logoWrap: { marginBottom: vscale(20) },
  logoBox: {
    width: fscale(90),
    height: fscale(90),
    borderRadius: fscale(22),
    backgroundColor: Colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoEmoji: { fontSize: fscale(40) },

  brandName: {
    ...Typography.h1,
    color: Colors.textInverse,
    marginBottom: Spacing.xs,
  },
  brandSub: {
    ...Typography.label,
    color: 'rgba(255,255,255,0.5)',
    letterSpacing: 1.5,
  },

  bottomWrap: {
    position: 'absolute',
    bottom: vscale(80),
    alignItems: 'center',
    gap: Spacing.sm,
  },
  region: {
    ...Typography.label,
    color: 'rgba(255,255,255,0.4)',
    letterSpacing: 1.5,
  },
});

export default SplashScreen;
