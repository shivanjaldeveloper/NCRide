import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Animated,
} from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { RootStackParamList } from '../../navigation/types';
import { ScreenShell } from '../../components/layout';
import { NCButton, PaginatorDots } from '../../components/common';
import {
  Colors,
  Typography,
  Spacing,
  fscale,
  vscale,
  SCREEN,
  Radii,
} from '../../theme';
import { ONBOARDING_SLIDES, OnboardingSlide } from './onboardingData';

type Props = NativeStackScreenProps<RootStackParamList, 'Onboarding'>;

// ─── Single slide ──────────────────────────────────────────────────────────
const Slide = ({ item }: { item: OnboardingSlide }) => (
  <View style={[styles.slide, { width: SCREEN.width }]}>
    {/* Illustration */}
    <View
      style={[
        styles.illustrationWrap,
        { backgroundColor: item.illustrationBg },
      ]}
    >
      <Text style={styles.illustrationEmoji}>{item.illustration}</Text>
    </View>

    {/* Copy */}
    <Text style={styles.title}>{item.title}</Text>
    <Text style={styles.subtitle}>{item.subtitle}</Text>
  </View>
);

// ─── Screen ────────────────────────────────────────────────────────────────
const OnboardingScreen = ({ navigation }: Props) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatRef = useRef<FlatList>(null);

  const isLast = activeIndex === ONBOARDING_SLIDES.length - 1;

  const handleNext = () => {
    if (isLast) {
      navigation.replace('OTPLogin');
      return;
    }
    const next = activeIndex + 1;
    flatRef.current?.scrollToIndex({ index: next, animated: true });
    setActiveIndex(next);
  };

  const handleSkip = () => {
    navigation.replace('OTPLogin');
  };

  return (
    <ScreenShell
      topColor={Colors.bgOffWhite}
      bottomColor={Colors.bgOffWhite}
      backgroundColor={Colors.bgOffWhite}
    >
      {/* Skip */}
      <TouchableOpacity
        style={styles.skipBtn}
        onPress={handleSkip}
        activeOpacity={0.7}
      >
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Slides */}
      <FlatList
        ref={flatRef}
        data={ONBOARDING_SLIDES}
        keyExtractor={item => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEnabled={false} // controlled programmatically
        renderItem={({ item }) => <Slide item={item} />}
      />

      {/* Bottom bar */}
      <View style={styles.bottomBar}>
        <PaginatorDots total={ONBOARDING_SLIDES.length} current={activeIndex} />
        <NCButton
          label={isLast ? 'Get started' : 'Next'}
          onPress={handleNext}
          fullWidth={false}
          style={styles.nextBtn}
        />
      </View>
    </ScreenShell>
  );
};

const styles = StyleSheet.create({
  skipBtn: {
    alignSelf: 'flex-end',
    paddingHorizontal: Spacing.screen,
    paddingVertical: Spacing.md,
  },
  skipText: {
    ...Typography.body,
    color: Colors.textSecondary,
  },

  slide: {
    flex: 1,
    paddingHorizontal: Spacing.screen,
    paddingTop: vscale(20),
    alignItems: 'flex-start',
  },
  illustrationWrap: {
    width: fscale(180),
    height: fscale(180),
    borderRadius: fscale(90),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: vscale(40),
  },
  illustrationEmoji: {
    fontSize: fscale(72),
  },
  title: {
    ...Typography.h2,
    color: Colors.textPrimary,
    marginBottom: Spacing.md,
    textAlign: 'left',
  },
  subtitle: {
    ...Typography.body,
    color: Colors.textSecondary,
    textAlign: 'left',
    lineHeight: fscale(22),
  },

  bottomBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.screen,
    paddingBottom: vscale(24),
    paddingTop: Spacing.lg,
  },
  nextBtn: {
    width: fscale(130),
    borderRadius: Radii.pill,
  },
});

export default OnboardingScreen;
